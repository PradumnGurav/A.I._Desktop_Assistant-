from Body.Speak import Speak
from Body.Listen import Listen

def MainExe():
    
    while True:
        queery = Listen().lower()
        print(queery)
        if "hello"  in queery:
            Speak("Hi, I am max.")

        elif "hi"  in queery:
            Speak("Hi, I am max. ")

        

        elif "bye"  in queery:
            Speak("Good Bye.")


